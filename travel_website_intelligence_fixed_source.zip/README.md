# Travel Website Intelligence

**Structured public tourism website analysis in a few clicks.**

Travel Website Intelligence is an Apify Actor for tour operators, travel agencies, hotels and agencies researching a business's public website. Enter a URL and examine up to **10 same-site HTML pages**. It extracts publicly displayed business, service and contact information into a dataset and a concise diagnostics report.

## What it collects

- Business name and website, where identifiable from metadata or structured data
- Tours, excursions, accommodation and other services mentioned on the pages
- Currency-tagged public prices associated with identifiable items
- Publicly stated durations and locations (duration-to-item associations where identifiable)
- Visible booking or reservation links, with associated tour names where identifiable
- Public business email/telephone and public social-media links
- Actual observation URLs for each finding, deduplicated across the visited pages

Results are **observations, not exhaustive competitive intelligence**. The Actor never invents missing values. It does not verify availability, booking status, official prices or service quality.

## Input

```json
{
  "url": "https://jijikux42.github.io/travel-agent-demo/",
  "maxPages": 1
}
```

| Setting | Required | Meaning |
|---|---|---|
| `url` | Yes | Public `https://` or `http://` site to examine |
| `maxPages` | No | Maximum HTML pages to crawl, 1–10; default 10 |

The example above is an **authorized fictional tourism demo**. Its prices are sample data and its booking links do not accept real reservations.

## Outputs

**Dataset:** One row per deduplicated finding, exportable as JSON or CSV. Fields depend on category:

- `category`: e.g. `prices`, `tours_and_services`, `booking_links`, `durations_and_locations`, `business`, `contacts`, `social_links`
- `source_url`: *first page where the finding was observed*, not the "original" or canonical source
- `source_urls`: other crawled URLs where the same finding was observed
- `found_on_pages`: count of observed URLs; **not** independent confirmations
- `item`, `name`, `amount`, `currency`, `value`, `url`, `context`, etc. as relevant

Example price finding:

```json
{
  "category": "prices",
  "source_url": "https://jijikux42.github.io/travel-agent-demo/",
  "item": "Kotor Bay Boat Trip",
  "amount": "60.00",
  "currency": "EUR",
  "context": "From €60.00 per adult",
  "source_urls": ["https://jijikux42.github.io/travel-agent-demo/"],
  "found_on_pages": 1
}
```

**Key-value store:**
- `REPORT`: JSON business intelligence summary, category counts, missing-field indicators, skipped pages, price observation URLs, and an explicit overlap note.
- `RESULTS.json`: array of findings.
- `RESULTS.csv`: CSV findings; nested lists are JSON strings.

**Blocked or empty pages** are reported with a warning, not treated as evidence that a business lacks the information.

## Usage and limitations

This Actor uses an inexpensive HTTP client and parser, **not a rendered browser**. JavaScript-only content may be missed; unusual HTML can defeat rule-based association. It respects parsed `robots.txt` directives when available, skips HTTP errors and never authenticates, solves CAPTCHAs or bypasses access restrictions. It is best suited to the business's own accessible HTML website, not large protected online travel marketplaces.

Prices and durations are interpreted from visible text or structured data; verify important decisions against the source site. Links labeled as booking actions may still lead to demo, request or external reservation pages rather than confirmed bookable availability.

The source does **not** activate pay-per-event charging. Any future paid launch requires publication approval, event setup, account payout configuration and a live validation run.

## Developer instructions

```bash
python -m unittest discover -s tests -v
python -m compileall -q my_actor
```

The tests include a **mocked HTTP Actor run**, a blocked HTTP response and regression checks using the fictional GitHub Pages HTML. Passing offline tests is **not** a successful Apify cloud deployment; build and validate a new source version on Apify before publication.
