"""Travel Website Intelligence: crawl up to 10 public pages of a travel business website."""

from __future__ import annotations

import csv
import io
import json
from collections import deque
from typing import Any
from urllib.parse import urldefrag, urljoin, urlparse
from urllib.robotparser import RobotFileParser

import httpx
from apify import Actor
from bs4 import BeautifulSoup

from .extractors import (
    extract_business_info,
    extract_contacts,
    extract_locations_and_durations,
    extract_prices,
    extract_social_links,
    extract_tours_and_services,
    nearest_tour_card_title,
)

HARD_MAX_PAGES = 10
USER_AGENT = 'TravelWebsiteIntelligenceBot/1.0 (+https://apify.com)'
REQUEST_TIMEOUT = 20.0
# A link is a booking link only when its path is a reservation/checkout flow, or its own visible
# text is a booking call-to-action. Product, catalogue and cart pages never count.
BOOKING_PATH_HINTS = ('/booking', '/book-now', '/reserve', '/reservation', '/availability', '/checkout', '/buy-ticket')
BOOKING_LABEL_HINTS = ('book now', 'book online', 'reserve now', 'reserve a', 'check availability', 'buy tickets', 'book this tour', 'book this room')
NON_BOOKING_PATH_HINTS = ('/catalogue/', '/products/', '/product/', '/shop/', '/cart', '/basket', '/blog', '/news')
SITE_TYPE_KEYWORDS = {
    'travel': ('tour', 'hotel', 'booking', 'excursion', 'room', 'accommodation', 'travel', 'trip', 'safari', 'activity'),
    'ecommerce': ('add to basket', 'add to cart', 'product', 'shop', 'in stock', 'checkout'),
    'news_or_blog': ('article', 'posted', 'blog', 'newsletter', 'read more'),
}
PAGE_PRIORITY_HINTS = ('tour', 'activit', 'room', 'accommodation', 'price', 'pricing', 'package', 'contact', 'about', 'book')
SKIP_EXTENSIONS = ('.pdf', '.jpg', '.jpeg', '.png', '.gif', '.svg', '.webp', '.zip', '.mp4', '.css', '.js', '.xml')
CATEGORY_KEYS = ('business', 'tours_and_services', 'prices', 'durations_and_locations', 'booking_links', 'contacts', 'social_links')


def _normalize(url: str) -> str:
    """Remove URL fragments without stripping the path's trailing slash.

    The slash is crucial on subpath-hosted sites such as GitHub Pages: without it,
    resolving `index.html?booking=...` would wrongly jump to the domain root.
    """
    return urldefrag(url)[0]


def _resolve(href: str, page_url: str) -> str:
    """Resolve against the *actual final page URL*, preserving query strings.

    A page URL returned by httpx retains its correct trailing slash. Never guess
    that an arbitrary extensionless URL is a directory: the server decides that.
    """
    href = href.strip()
    if not href:
        return ''
    resolved = _normalize(urljoin(page_url, href))
    parsed = urlparse(resolved)
    if parsed.scheme.lower() not in ('http', 'https') or not parsed.netloc:
        return ''
    return resolved


def _same_site(url: str, base_host: str) -> bool:
    host = urlparse(url).netloc.lower().removeprefix('www.')
    return host == base_host.removeprefix('www.')


async def _load_robots(client: httpx.AsyncClient, base_url: str) -> RobotFileParser | None:
    parser = RobotFileParser()
    try:
        resp = await client.get(urljoin(base_url, '/robots.txt'))
        if resp.status_code == 200:
            parser.parse(resp.text.splitlines())
            return parser
    except httpx.HTTPError:
        pass
    return None  # no robots.txt, or it could not be read: treat as allowed


def _allowed(robots: RobotFileParser | None, url: str) -> bool:
    return robots is None or robots.can_fetch(USER_AGENT, url)


def _is_booking_link(href: str, label: str) -> bool:
    parsed = urlparse(href)
    path = parsed.path.lower()
    if any(h in path for h in NON_BOOKING_PATH_HINTS):
        return False
    label_l = label.lower().strip()
    if label_l in ('add to basket', 'add to cart', 'buy now'):
        return False
    if any(h in path for h in BOOKING_PATH_HINTS):
        return True
    if any(k in parsed.query.lower() for k in ('booking=', 'reserve=', 'reservation=')):
        return True
    return any(label_l == h or label_l.startswith(h) for h in BOOKING_LABEL_HINTS)


def _booking_links(soup: BeautifulSoup, page_url: str) -> list[dict]:
    results, seen = [], set()
    for a in soup.find_all('a', href=True):
        href = _resolve(a['href'], page_url)
        label = a.get_text(' ', strip=True)[:120]
        if not href.startswith(('http://', 'https://')):
            continue
        if _is_booking_link(href, label) and href not in seen:
            seen.add(href)
            results.append({'label': label or None, 'url': href, 'item': nearest_tour_card_title(a)})
    return results[:30]


def _internal_links(soup: BeautifulSoup, page_url: str, base_host: str) -> list[str]:
    links = []
    for a in soup.find_all('a', href=True):
        href = _resolve(a['href'], page_url)
        if not href.startswith(('http://', 'https://')):
            continue
        if not _same_site(href, base_host) or href.lower().endswith(SKIP_EXTENSIONS):
            continue
        links.append(href)
    return links


def _prioritize(links: list[str]) -> list[str]:
    """Put business-relevant pages first (tours, rooms, prices, contact, booking)."""
    return sorted(dict.fromkeys(links), key=lambda u: 0 if any(h in u.lower() for h in PAGE_PRIORITY_HINTS) else 1)


def _finding(category: str, source_url: str, **fields: Any) -> dict:
    return {'category': category, 'source_url': source_url, **{k: v for k, v in fields.items() if v not in (None, '', [])}}


def _detect_site_type(pages_text: str, has_tours: bool) -> str:
    """Classify the site from the words on its pages, so reports only give relevant advice."""
    text = pages_text.lower()
    scores = {k: sum(text.count(w) for w in words) for k, words in SITE_TYPE_KEYWORDS.items()}
    if has_tours:
        scores['travel'] += 5
    best, score = max(scores.items(), key=lambda kv: kv[1])
    return best if score >= 5 else 'general'


def _build_report(findings: list[dict], pages_visited: list[str], skipped: list[dict], site_type: str) -> dict:
    by_cat: dict[str, int] = {k: 0 for k in CATEGORY_KEYS}
    for f in findings:
        by_cat[f['category']] = by_cat.get(f['category'], 0) + 1

    tours = [f for f in findings if f['category'] == 'tours_and_services']
    prices = [f for f in findings if f['category'] == 'prices']
    booking = [f for f in findings if f['category'] == 'booking_links']
    contacts = [f for f in findings if f['category'] == 'contacts']
    socials = [f for f in findings if f['category'] == 'social_links']
    is_travel = site_type == 'travel'

    issues, opportunities = [], []
    if is_travel and tours and not prices:
        issues.append('Tours or services were found, but no publicly displayed prices.')
    if is_travel and tours and not booking:
        issues.append('No booking links were found on the crawled pages.')
    if not contacts:
        issues.append('No public email or phone contact was found on the crawled pages.')
    if is_travel and not socials:
        opportunities.append('No social media links were found. Adding them can improve discoverability.')
    if prices and not any(f.get('currency') for f in prices):
        opportunities.append('Prices are shown without a clear currency.')
    if is_travel and tours and prices:
        opportunities.append('Price visibility is good; keep prices consistent across tour pages.')
    if skipped:
        opportunities.append(f'{len(skipped)} page(s) were skipped (blocked, disallowed or unreachable); check access rules.')

    return {
        'site_type': site_type,
        'pages_crawled': len(pages_visited),
        'pages': pages_visited,
        'pages_skipped': skipped,
        'counts': by_cat,
        'missing_prices': bool(is_travel and tours and not prices),
        'missing_booking_links': bool(is_travel and tours and not booking),
        'issues': issues,
        'improvement_opportunities': opportunities,
        'disclaimer': 'Based only on publicly accessible pages crawled. Missing data means not found, not confirmed absent. source_url is the first observed page; overlapping pages are not independent corroboration.',
        'source_attribution_note': 'source_url is the first observed page (not a canonical or original source). source_urls lists each crawled page that displayed the finding; overlap does not imply independent evidence.',
        'overlapping_findings': [
            {'category': f['category'], 'name_or_item': f.get('item') or f.get('name') or f.get('value') or f.get('url'),
             'first_seen_url': f['source_url'], 'observed_on_pages': f['found_on_pages'],
             'observed_urls': f['source_urls']}
            for f in findings if f.get('found_on_pages', 1) > 1
        ],
    }


def _dedupe_findings(findings: list[dict]) -> list[dict]:
    """Merge identical findings across pages.

    source_url is the first observed page, NOT a canonical source or true origin.
    source_urls lists all crawled pages where this finding was *observed*.
    found_on_pages counts observed URL variations, not independent evidence.
    """
    merged: dict[tuple, dict] = {}
    for f in findings:
        key = tuple(sorted((k, str(v).lower()) for k, v in f.items() if k not in ('source_url', 'source_urls', 'context')))
        if key in merged:
            seen_on = merged[key]['source_urls']
            if f['source_url'] not in seen_on:
                seen_on.append(f['source_url'])
        else:
            merged[key] = {**f, 'source_urls': [f['source_url']]}
    for item in merged.values():
        item['found_on_pages'] = len(item['source_urls'])
    return list(merged.values())


def _to_csv(items: list[dict]) -> str:
    keys = sorted({k for item in items for k in item.keys()})
    buf = io.StringIO()
    writer = csv.DictWriter(buf, fieldnames=keys)
    writer.writeheader()
    for item in items:
        writer.writerow({k: (v if not isinstance(v, (list, dict)) else json.dumps(v, ensure_ascii=False)) for k, v in item.items()})
    return buf.getvalue()


async def run() -> None:
    async with Actor:
        actor_input = await Actor.get_input() or {}
        start_url = str(actor_input.get('url', '')).strip()
        try:
            max_pages = int(actor_input.get('maxPages', HARD_MAX_PAGES))
        except (TypeError, ValueError):
            await Actor.fail(status_message='Input maxPages must be an integer from 1 to 10.')
            return
        if not 1 <= max_pages <= HARD_MAX_PAGES:
            await Actor.fail(status_message='Input maxPages must be between 1 and 10.')
            return

        parsed = urlparse(start_url)
        if parsed.scheme not in ('http', 'https') or not parsed.netloc:
            await Actor.fail(status_message='Input "url" must be a public http(s) URL.')
            return

        start_url = _normalize(start_url)
        base_host = parsed.netloc.lower()
        Actor.log.info(f'Crawling {start_url} (max {max_pages} pages)')

        findings: list[dict] = []
        pages_text: list[str] = []
        pages_visited: list[str] = []
        skipped: list[dict] = []
        queue: deque[str] = deque([start_url])
        seen: set[str] = {start_url}

        headers = {
            'User-Agent': USER_AGENT,
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'en,sq;q=0.9,*;q=0.5',
        }
        async with httpx.AsyncClient(headers=headers, timeout=REQUEST_TIMEOUT, follow_redirects=True) as client:
            robots = await _load_robots(client, start_url)

            while queue and len(pages_visited) < max_pages:
                url = queue.popleft()
                if not _allowed(robots, url):
                    skipped.append({'url': url, 'reason': 'disallowed by robots.txt'})
                    Actor.log.info(f'Skipping (robots.txt): {url}')
                    continue
                try:
                    resp = await client.get(url)
                except httpx.HTTPError as exc:
                    skipped.append({'url': url, 'reason': f'request error: {type(exc).__name__}'})
                    Actor.log.warning(f'Request failed for {url}: {exc}')
                    continue

                if resp.status_code in (401, 403, 429) or resp.status_code >= 400:
                    skipped.append({'url': url, 'reason': f'HTTP {resp.status_code}'})
                    Actor.log.info(f'Skipping {url}: HTTP {resp.status_code}')
                    continue
                if 'text/html' not in resp.headers.get('content-type', ''):
                    skipped.append({'url': url, 'reason': 'not an HTML page'})
                    continue

                final_url = _normalize(str(resp.url))
                if not _same_site(final_url, base_host):
                    skipped.append({'url': url, 'reason': 'redirected to another site'})
                    continue

                pages_visited.append(final_url)
                try:
                    soup = BeautifulSoup(resp.text, 'lxml')
                    pages_text.append(soup.get_text(' ', strip=True)[:20000])
                    findings.extend(_page_findings(soup, final_url))
                    for link in _prioritize(_internal_links(soup, final_url, base_host)):
                        if link not in seen and len(seen) < 200:
                            seen.add(link)
                            queue.append(link)
                except Exception as exc:  # noqa: BLE001 - one bad page must not stop the run
                    skipped.append({'url': url, 'reason': f'parse error: {type(exc).__name__}'})
                    Actor.log.exception(f'Failed to parse {url}')

        findings = _dedupe_findings(findings)
        for item in findings:
            await Actor.push_data(item)

        has_tours = any(f['category'] == 'tours_and_services' for f in findings)
        site_type = _detect_site_type(' '.join(pages_text), has_tours)
        report = _build_report(findings, pages_visited, skipped, site_type)
        report['price_sources'] = [
            {'amount': f.get('amount'), 'currency': f.get('currency'), 'item': f.get('item'),
             'first_seen_url': f['source_url'], 'source_urls': f.get('source_urls') or [f['source_url']],
             'observed_on_pages': f.get('found_on_pages', 1)}
            for f in findings if f['category'] == 'prices'
        ]
        if not findings:
            report['warning'] = 'No findings were extracted. This may be due to blocked access, empty pages, or unsupported page structure, not proof that the business has no data.'
        await Actor.set_value('REPORT', report)
        await Actor.set_value('RESULTS.json', findings)
        await Actor.set_value('RESULTS.csv', _to_csv(findings), content_type='text/csv')

        Actor.log.info(f'Done: {len(pages_visited)} pages, {len(findings)} findings, {len(skipped)} skipped.')


def _page_findings(soup: BeautifulSoup, url: str) -> list[dict]:
    out: list[dict] = []
    for b in extract_business_info(soup, url):
        out.append(_finding('business', url, name=b.get('name'), website=b.get('website'), summary=b.get('description'), type=b.get('type')))
    for t in extract_tours_and_services(soup):
        out.append(_finding('tours_and_services', url, name=t.get('name'), kind=t.get('kind'), summary=t.get('description')))
    for p in extract_prices(soup):
        out.append(_finding('prices', url, item=p.get('item'), amount=p.get('amount'), currency=p.get('currency'), context=p.get('context')))
    for d in extract_locations_and_durations(soup):
        out.append(_finding('durations_and_locations', url, type=d.get('type'), item=d.get('item'), value=d.get('value'), context=d.get('context')))
    for link in _booking_links(soup, url):
        out.append(_finding('booking_links', url, name=link.get('label'), item=link.get('item'), url=link.get('url')))
    for c in extract_contacts(soup):
        out.append(_finding('contacts', url, type=c.get('type'), value=c.get('value')))
    for platform, link in extract_social_links(soup):
        out.append(_finding('social_links', url, platform=platform, url=link))
    return out
