"""Rule-based extractors. Each function returns only what is literally present on the page.

Nothing is inferred or invented: a missing value yields no item.
"""

from __future__ import annotations

import json
import re
from urllib.parse import urlparse

from bs4 import BeautifulSoup

CURRENCY_SYMBOLS = {'€': 'EUR', '£': 'GBP', '$': 'USD', '¥': 'JPY', '₹': 'INR', 'Kč': 'CZK', 'zł': 'PLN'}
ISO_CURRENCIES = r'(?:EUR|USD|GBP|CZK|PLN|CHF|JPY|AUD|CAD|INR|THB|VND|MXN|SEK|NOK|DKK)'
PRICE_RE = re.compile(
    rf'(?P<pre>{ISO_CURRENCIES}|[€£$¥₹]|Kč|zł)\s?(?P<amount>\d{{1,3}}(?:[ ,.]\d{{3}})*(?:[.,]\d{{1,2}})?)'
    rf'|(?P<amount2>\d{{1,3}}(?:[ ,.]\d{{3}})*(?:[.,]\d{{1,2}})?)\s?(?P<post>{ISO_CURRENCIES}|€|£|Kč|zł)',
    re.IGNORECASE,
)
DURATION_RE = re.compile(
    r'\b(\d+(?:[.,]\d+)?\s?(?:hours?|hrs?|h|minutes?|mins?|days?|nights?|weeks?)'
    r'(?:\s?(?:-|–|to)\s?\d+(?:[.,]\d+)?\s?(?:hours?|hrs?|h|days?|nights?))?)\b',
    re.IGNORECASE,
)
EMAIL_RE = re.compile(r'[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}')
PHONE_RE = re.compile(r'(?:\+\d{1,3}[\s.-]?)?(?:\(?\d{2,4}\)?[\s.-]?)\d{3}[\s.-]?\d{3,4}')
SOCIAL_HOSTS = {
    'facebook.com': 'facebook', 'fb.com': 'facebook', 'instagram.com': 'instagram',
    'twitter.com': 'x', 'x.com': 'x', 'linkedin.com': 'linkedin', 'youtube.com': 'youtube',
    'tiktok.com': 'tiktok', 'pinterest.com': 'pinterest', 'tripadvisor.com': 'tripadvisor',
}
TOUR_KEYWORDS = re.compile(
    r'\b(tour|tours|trip|trips|boat|activity|activities|excursion|experience|package|cruise|safari|trek|hike|'
    r'room|suite|accommodation|apartment|villa|lodging|class|workshop|transfer|ticket)s?\b',
    re.IGNORECASE,
)
LOCATION_HINT = re.compile(r'\b(in|from|at|near|meeting point|departs?)\s+([A-Z][\w\s-]{2,40})')


def _text(el) -> str:
    return re.sub(r'\s+', ' ', el.get_text(' ', strip=True)) if el else ''


def _jsonld_objects(soup: BeautifulSoup):
    for script in soup.find_all('script', type='application/ld+json'):
        try:
            data = json.loads(script.string or '')
        except (json.JSONDecodeError, TypeError):
            continue
        stack = [data]
        while stack:
            node = stack.pop()
            if isinstance(node, list):
                stack.extend(node)
            elif isinstance(node, dict):
                if '@graph' in node:
                    stack.append(node['@graph'])
                yield node


def _meta(soup: BeautifulSoup, *names: str) -> str | None:
    for name in names:
        tag = soup.find('meta', attrs={'property': name}) or soup.find('meta', attrs={'name': name})
        if tag and tag.get('content'):
            return tag['content'].strip()
    return None


def extract_business_info(soup: BeautifulSoup, page_url: str) -> list[dict]:
    """Business name, website and description from schema.org data, meta tags, or the title.

    Priority: schema.org Organization/LocalBusiness-type nodes, then og:site_name, then application-name.
    The page <title> is only used as a last resort, and only the part before a separator.
    """
    results = []
    for node in _jsonld_objects(soup):
        node_type = node.get('@type')
        types = node_type if isinstance(node_type, list) else [node_type]
        if any(t in ('Organization', 'LocalBusiness', 'Hotel', 'TravelAgency', 'LodgingBusiness',
                     'TouristAttraction', 'Corporation', 'Place') for t in types if t):
            if node.get('name'):
                results.append({
                    'name': str(node['name']).strip(),
                    'website': node.get('url'),
                    'description': (node.get('description') or '')[:300] or None,
                    'type': ', '.join(t for t in types if t),
                })
    if not results:
        site_name = _meta(soup, 'og:site_name', 'application-name')
        if site_name:
            name, source = site_name, 'meta'
        else:
            name, source = None, None
        if name:
            results.append({
                'name': name,
                'website': _meta(soup, 'og:url') or page_url,
                'description': (_meta(soup, 'og:description', 'description') or '')[:300] or None,
                'type': None,
            })
    return _dedupe_dicts(results, ('name', 'website'))[:3]


def _dedupe_dicts(items: list[dict], keys: tuple[str, ...]) -> list[dict]:
    seen, out = set(), []
    for item in items:
        sig = tuple(str(item.get(k) or '').lower() for k in keys)
        if sig not in seen:
            seen.add(sig)
            out.append(item)
    return out



# Headings such as "Our demo tours" describe a collection, not an individual offer.
GENERIC_TOUR_HEADINGS = {
    'tours', 'our tours', 'our demo tours', 'sample tours', 'all tours',
    'featured tours', 'popular tours', 'tour catalogue', 'tour catalog',
    'tour packages', 'travel experiences', 'our experiences', 'activities',
    'our activities', 'sample tours transparent prices clean source links',
}


def _is_generic_tour_heading(text: str) -> bool:
    normalized = re.sub(r'[^\w\s]', ' ', text.lower()).strip()
    normalized = re.sub(r'\s+', ' ', normalized)
    return (not normalized or normalized in GENERIC_TOUR_HEADINGS
            or normalized.startswith(('sample tours ', 'our demo tours ', 'browse tours ',
                                      'explore tours ', 'all our tours ')))


def nearest_tour_card_title(node) -> str | None:
    """Only identify a nearby *individual* card, never a page-wide tour heading."""
    for parent in [node] + list(node.parents):
        if getattr(parent, 'name', None) is None:
            continue
        classes = parent.get('class', []) if hasattr(parent, 'get') else []
        if (parent.name in ('article', 'li', 'tr') or
                any(part in str(cls).lower() for cls in classes for part in ('tour-card', 'product-card', 'activity-card')) or
                parent.has_attr('data-tour')):
            headings = parent.find_all(['h1', 'h2', 'h3', 'h4'], limit=5)
            for heading in headings:
                title = _text(heading)
                if TOUR_KEYWORDS.search(title) and not _is_generic_tour_heading(title):
                    return title[:120]
            return None
        if parent.name in ('main', 'body'):
            break
    return None


def _tour_kind(name: str) -> str:
    lower = name.lower()
    if re.search(r'\bboat\b', lower) and re.search(r'\b(trip|tour|cruise)\b', lower):
        return 'boat_trip'
    match = TOUR_KEYWORDS.search(name)
    return match.group(1).lower() if match else 'tour'


def extract_tours_and_services(soup: BeautifulSoup) -> list[dict]:
    """Headings and product items that mention tours, rooms or activities."""
    results, seen = [], set()
    for tag in soup.find_all(['h1', 'h2', 'h3', 'h4']):
        text = _text(tag)
        if (3 <= len(text) <= 120 and TOUR_KEYWORDS.search(text)
                and not _is_generic_tour_heading(text) and text.lower() not in seen):
            seen.add(text.lower())
            kind = _tour_kind(text)
            results.append({'name': text, 'kind': kind, 'description': None})
    for node in _jsonld_objects(soup):
        node_type = node.get('@type')
        types = node_type if isinstance(node_type, list) else [node_type]
        if any(t in ('Product', 'TouristTrip', 'Offer', 'Service', 'TouristAttraction') for t in types if t):
            name = node.get('name')
            if name and str(name).lower() not in seen:
                seen.add(str(name).lower())
                results.append({'name': str(name).strip(), 'kind': 'structured_data', 'description': (node.get('description') or '')[:300] or None})
    return results[:25]


CTA_NOISE = re.compile(
    r'\b(add to basket|add to cart|in stock|out of stock|buy now|book now|read more|view details|quick view)\b',
    re.IGNORECASE,
)
PRICE_CONTAINER_TAGS = ('li', 'article', 'tr', 'td', 'div', 'section', 'p', 'figure')


def _price_label(el, max_len: int = 120) -> str | None:
    """Name of the product, tour or room that a price belongs to: the nearest heading or link text
    inside the same container as the price. Returns None when nothing reliable is found."""
    for ancestor in [el] + list(el.parents):
        if ancestor is None or getattr(ancestor, 'name', None) not in PRICE_CONTAINER_TAGS + ('body',):
            continue
        titled = ancestor.find('a', attrs={'title': True})
        heading = ancestor.find(['h1', 'h2', 'h3', 'h4', 'h5'])
        label = _text(heading) if heading else ''
        # Truncated headings end with an ellipsis; the link's title attribute holds the full name.
        if titled and (not label or label.endswith('...')) and 2 <= len(titled['title']) <= max_len:
            return titled['title'].strip()
        if 2 <= len(label) <= max_len:
            return label
        if titled and 2 <= len(titled['title']) <= max_len:
            return titled['title'].strip()
        if ancestor.name in ('li', 'article', 'tr', 'figure', 'body'):
            break
    return None


def _price_fragment(text: str, match: re.Match) -> str:
    """The sentence-sized fragment around one price, without neighbouring items."""
    start = max(text.rfind(' ', 0, max(0, match.start() - 40)), 0)
    end = text.find(' ', match.end() + 20)
    fragment = text[start:end if end != -1 else len(text)]
    return re.sub(r'\s+', ' ', CTA_NOISE.sub('', fragment)).strip(' -|·')[:200]


def extract_prices(soup: BeautifulSoup) -> list[dict]:
    """Prices with currency, only when a currency marker sits directly next to the number.

    Each price is tied to the card or container it sits in. The item label is the heading or titled
    link of that same container. A price with no identifiable item is dropped rather than guessed,
    because a price with no product attached is misleading. Duplicates are removed.
    """
    results, seen = [], set()
    for node in soup.find_all(string=PRICE_RE):
        container = node.parent
        while container is not None and getattr(container, 'name', None) not in PRICE_CONTAINER_TAGS:
            container = container.parent
        if container is None:
            continue
        label = _price_label(container)
        if not label:
            continue  # no identifiable item for this price: drop it rather than guess
        block = re.sub(r'\s+', ' ', _text(container))[:300]
        for m in PRICE_RE.finditer(block):
            raw_currency = m.group('pre') or m.group('post')
            amount = m.group('amount') or m.group('amount2')
            if not raw_currency or not amount:
                continue
            currency = CURRENCY_SYMBOLS.get(raw_currency, raw_currency.upper())
            key = (label.lower(), amount, currency)
            if key in seen:
                continue
            seen.add(key)
            results.append({'item': label, 'amount': amount, 'currency': currency,
                            'context': _price_fragment(block, m)})
            if len(results) >= 30:
                return results
    for node in _jsonld_objects(soup):
        offers = node.get('offers')
        if isinstance(offers, dict) and offers.get('price') is not None and offers.get('priceCurrency'):
            name = node.get('name')
            if not name:
                continue
            key = (str(name).lower(), str(offers['price']), offers['priceCurrency'])
            if key not in seen:
                seen.add(key)
                results.append({'item': str(name).strip(), 'amount': str(offers['price']),
                                'currency': offers['priceCurrency'], 'context': 'structured data offer'})
    return results[:30]


def extract_locations_and_durations(soup: BeautifulSoup) -> list[dict]:
    text = soup.get_text(' ', strip=True)
    results, seen = [], set()
    for text_node in soup.find_all(string=DURATION_RE):
        fragment = str(text_node).strip()
        item = nearest_tour_card_title(text_node)
        for m in DURATION_RE.finditer(fragment):
            value = m.group(1)
            key = ('duration', value.lower(), (item or '').lower())
            if key not in seen:
                seen.add(key)
                results.append({'type': 'duration', 'item': item, 'value': value, 'context': fragment[:200]})
    for m in LOCATION_HINT.finditer(text):
        value = m.group(2).strip()
        if value.lower() not in seen and len(value) > 2:
            seen.add(value.lower())
            results.append({'type': 'location', 'value': value, 'context': m.group(0)})
    for node in _jsonld_objects(soup):
        addr = node.get('address')
        if isinstance(addr, dict):
            locality = addr.get('addressLocality') or addr.get('streetAddress')
            if locality and str(locality).lower() not in seen:
                seen.add(str(locality).lower())
                results.append({'type': 'location', 'value': str(locality).strip(), 'context': 'structured data address'})
    return results[:30]


def extract_contacts(soup: BeautifulSoup) -> list[dict]:
    results, seen = [], set()
    for a in soup.find_all('a', href=True):
        href = a['href']
        if href.lower().startswith('mailto:'):
            email = href[7:].split('?')[0].strip()
            if email and email.lower() not in seen:
                seen.add(email.lower())
                results.append({'type': 'email', 'value': email})
        elif href.lower().startswith('tel:'):
            phone = href[4:].strip()
            if phone and phone not in seen:
                seen.add(phone)
                results.append({'type': 'phone', 'value': phone})
    text = soup.get_text(' ', strip=True)
    for email in EMAIL_RE.findall(text):
        if email.lower() not in seen:
            seen.add(email.lower())
            results.append({'type': 'email', 'value': email})
    for m in PHONE_RE.finditer(text):
        phone = m.group(0).strip()
        digits = re.sub(r'\D', '', phone)
        if 8 <= len(digits) <= 15 and phone not in seen:
            seen.add(phone)
            results.append({'type': 'phone', 'value': phone})
    return results[:20]


def extract_social_links(soup: BeautifulSoup) -> list[tuple[str, str]]:
    found, seen = [], set()
    candidates = [a['href'] for a in soup.find_all('a', href=True)]
    for node in _jsonld_objects(soup):
        same_as = node.get('sameAs')
        if isinstance(same_as, str):
            candidates.append(same_as)
        elif isinstance(same_as, list):
            candidates.extend(s for s in same_as if isinstance(s, str))
    for href in candidates:
        host = urlparse(href).netloc.lower().removeprefix('www.')
        for domain, platform in SOCIAL_HOSTS.items():
            if host == domain or host.endswith('.' + domain):
                if href not in seen:
                    seen.add(href)
                    found.append((platform, href))
                break
    return found[:20]
