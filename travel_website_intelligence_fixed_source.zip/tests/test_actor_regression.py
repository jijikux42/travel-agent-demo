"""Offline tests run with `python -m unittest discover -s tests -v`.

The Apify SDK is stubbed ONLY when it isn't installed; these tests don't spend
Apify compute and do not modify the actual Actor on Apify.
"""
import asyncio
import csv
import io
import json
from pathlib import Path
import sys
import types
import unittest
from unittest.mock import patch
from urllib.parse import urlparse

import httpx
from bs4 import BeautifulSoup

if 'apify' not in sys.modules:
    try:
        import apify
    except ImportError:
        sys.modules['apify'] = types.SimpleNamespace(Actor=object())

from my_actor import main
from my_actor import extractors

DEMO_URL = 'https://jijikux42.github.io/travel-agent-demo/'
DEMO_HTML = (Path(__file__).parent / 'fixtures' / 'index.html').read_text(encoding='utf-8')
EXPECTED = {
    'Dubrovnik Old Town Walking Tour': ('45.00', 'EUR', '2 hours', 'dubrovnik-walking-tour'),
    'Kotor Bay Boat Trip': ('60.00', 'EUR', '3 hours', 'kotor-bay-boat-trip'),
    'Vlorë Coastal Experience': ('40.00', 'EUR', '4 hours', 'vlore-coastal-experience'),
}

class ExtractionTests(unittest.TestCase):
    def setUp(self):
        self.soup = BeautifulSoup(DEMO_HTML, 'lxml')
        self.findings = main._dedupe_findings(main._page_findings(self.soup, DEMO_URL))

    def test_directory_url_keeps_trailing_slash(self):
        self.assertEqual(main._normalize(DEMO_URL), DEMO_URL)
        self.assertEqual(main._resolve('index.html?booking=kotor#booking', DEMO_URL),
                         DEMO_URL + 'index.html?booking=kotor')
        self.assertEqual(main._resolve('mailto:x@example.com', DEMO_URL), '')
        self.assertEqual(main._resolve('javascript:alert(1)', DEMO_URL), '')

    def test_exact_three_tours_and_no_generic_titles(self):
        tours = [x for x in self.findings if x['category'] == 'tours_and_services']
        self.assertEqual(set(x['name'] for x in tours), set(EXPECTED))
        self.assertEqual(len(tours), 3)
        self.assertEqual(next(x['kind'] for x in tours if x['name'].startswith('Kotor')), 'boat_trip')

    def test_prices_belong_to_tours(self):
        rows = [x for x in self.findings if x['category'] == 'prices']
        self.assertEqual(len(rows), 3)
        for x in rows:
            amount, currency, _, _ = EXPECTED[x['item']]
            self.assertEqual((x['amount'], x['currency']), (amount, currency))
            self.assertEqual(x['source_url'], DEMO_URL)

    def test_durations_associated_with_tour(self):
        rows = [x for x in self.findings if x['category'] == 'durations_and_locations' and x['type']=='duration']
        self.assertEqual(len(rows), 3)
        for x in rows:
            self.assertEqual(x['value'], EXPECTED[x['item']][2])

    def test_booking_links_have_correct_path_and_association(self):
        rows = [x for x in self.findings if x['category'] == 'booking_links']
        self.assertEqual(len(rows), 3)
        for x in rows:
            self.assertEqual(urlparse(x['url']).path, '/travel-agent-demo/index.html')
            self.assertIn('booking='+EXPECTED[x['item']][3], x['url'])
            self.assertNotIn('#', x['url'])
            self.assertTrue(x['name'].startswith('Book now'))

    def test_price_is_not_attached_to_other_card(self):
        html = '<article class="tour-card"><h2>First City Walking Tour</h2><p>€45</p></article><article class="tour-card"><h2>Second Boat Trip</h2><p>€60</p></article>'
        rows = extractors.extract_prices(BeautifulSoup(html, 'lxml'))
        self.assertEqual({x['item']: x['amount'] for x in rows}, {'First City Walking Tour':'45', 'Second Boat Trip':'60'})

    def test_book_catalogue_regression(self):
        html = '''<html><body><ol><li class="product_pod"><h3><a href="catalogue/one" title="A Light in the Attic">A Light in the...</a></h3><p class="price_color">£51.77</p><a href="catalogue/one">View product</a></li><li class="product_pod"><h3><a href="catalogue/two" title="The Secret Garden">The Secret Garden</a></h3><p class="price_color">£24.10</p></li></ol></body></html>'''
        soup = BeautifulSoup(html, 'lxml')
        prices = extractors.extract_prices(soup)
        self.assertEqual({p['item']:(p['amount'],p['currency']) for p in prices},
                         {'A Light in the Attic':('51.77','GBP'),'The Secret Garden':('24.10','GBP')})
        self.assertEqual(main._booking_links(soup,'https://books.toscrape.com/'),[])

    def test_plain_product_link_is_not_booking(self):
        self.assertFalse(main._is_booking_link('https://example.org/catalogue/books/', 'View product'))
        self.assertFalse(main._is_booking_link('https://example.org/product/12', 'Add to basket'))
        self.assertTrue(main._is_booking_link(DEMO_URL+'index.html?booking=x', 'Book now (demo)'))

    def test_overlap_source_is_observation_not_canonical_origin(self):
        page2 = 'https://jijikux42.github.io/travel-agent-demo/index.html?test=1'
        source1 = main._page_findings(self.soup, DEMO_URL)
        source2 = main._page_findings(self.soup, page2)
        merged = main._dedupe_findings(source1+source2)
        row = next(x for x in merged if x['category']=='prices' and x['item']=='Kotor Bay Boat Trip')
        self.assertEqual(row['source_url'], DEMO_URL)
        self.assertEqual(row['source_urls'], [DEMO_URL,page2])
        self.assertEqual(row['found_on_pages'],2)
        report = main._build_report(merged, [DEMO_URL,page2], [], 'travel')
        self.assertEqual(len(report['overlapping_findings'])>0,True)
        self.assertIn('does not imply independent', report['source_attribution_note'])

    def test_csv_and_json_schema_are_correct(self):
        buf=io.StringIO(main._to_csv(self.findings))
        rows=list(csv.DictReader(buf))
        self.assertEqual(len(rows),len(self.findings))
        self.assertIsInstance(json.loads(rows[0]['source_urls']),list)
        ds=json.loads((Path(__file__).parents[1]/'.actor/dataset_schema.json').read_text())
        self.assertTrue({'item','source_urls','found_on_pages'} <= set(ds['fields']['properties']))

    def test_report_and_empty_run_status(self):
        report=main._build_report(self.findings,[DEMO_URL],[],'travel')
        self.assertEqual(report['pages_crawled'],1)
        self.assertEqual(report['counts']['tours_and_services'],3)
        self.assertEqual(report['counts']['prices'],3)
        self.assertEqual(report['counts']['booking_links'],3)
        self.assertFalse(report['missing_prices'])
        self.assertFalse(report['missing_booking_links'])


class FakeLog:
    def info(self,*a,**kw): pass
    def warning(self,*a,**kw): pass
    def exception(self,*a,**kw): pass

class FakeActor:
    def __init__(self,input_url=DEMO_URL):
        self.input_url=input_url
        self.dataset=[]
        self.kv={}
        self.failed=False
        self.log=FakeLog()
    async def __aenter__(self):return self
    async def __aexit__(self,*args):return False
    async def get_input(self):return {'url':self.input_url,'maxPages':1}
    async def push_data(self,item):self.dataset.append(item)
    async def set_value(self,key,data,**kw):self.kv[key]=data
    async def fail(self,**kw):self.failed=True

class EndToEndTests(unittest.IsolatedAsyncioTestCase):
    async def test_complete_mocked_http_run(self):
        original_async_client=httpx.AsyncClient
        def handler(request):
            if request.url.path.endswith('/robots.txt'):
                return httpx.Response(404)
            if request.url.path == '/travel-agent-demo/':
                return httpx.Response(200, text=DEMO_HTML, headers={'Content-Type':'text/html'})
            return httpx.Response(404)
        def factory(*args,**kwargs):
            kwargs['transport']=httpx.MockTransport(handler)
            return original_async_client(*args,**kwargs)
        actor=FakeActor()
        with patch.object(main,'Actor',actor),patch.object(main.httpx,'AsyncClient',side_effect=factory):
            await main.run()
        self.assertFalse(actor.failed)
        self.assertEqual(actor.kv['REPORT']['pages_crawled'],1)
        self.assertEqual(actor.kv['REPORT']['counts']['prices'],3)
        self.assertEqual(actor.kv['REPORT']['counts']['booking_links'],3)
        self.assertIn('RESULTS.csv',actor.kv)
        self.assertIn('RESULTS.json',actor.kv)
        self.assertEqual(len(actor.dataset),len(actor.kv['RESULTS.json']))

    async def test_blocked_http_has_no_findings_and_warns(self):
        original_async_client=httpx.AsyncClient
        def factory(*args,**kwargs):
            kwargs['transport']=httpx.MockTransport(lambda request:httpx.Response(406))
            return original_async_client(*args,**kwargs)
        actor=FakeActor()
        with patch.object(main,'Actor',actor),patch.object(main.httpx,'AsyncClient',side_effect=factory):
            await main.run()
        self.assertFalse(actor.failed)
        self.assertEqual(len(actor.dataset),0)
        self.assertEqual(actor.kv['REPORT']['pages_crawled'],0)
        self.assertEqual(actor.kv['REPORT']['pages_skipped'][0]['reason'],'HTTP 406')
        self.assertIn('warning',actor.kv['REPORT'])

if __name__=='__main__':
    unittest.main()
