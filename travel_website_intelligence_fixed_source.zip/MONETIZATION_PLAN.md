# Monetization proposal — not activated

**Product model:** One custom event `completed-report` at an illustrative **$0.25** per successfully generated, useful report. Do not charge one event for each raw item, because the count and customer bill would be unpredictable.

**Quality gate proposal:** Only consider the report complete when at least one public HTML page was successfully crawled, the generated REPORT/JSON/CSV are present, and the report contains at least one meaningful, sourced tourism finding (such as a tour offer paired with a price or genuine booking link). Pages skipped due to HTTP errors do not qualify.

**Important:** No `Actor.charge(...)` call is added in this package. You must configure pricing events and integrate the SDK's official charging mechanism *after* confirming Apify's active event names and your account settings, then test idempotency and spending-limit behavior. Avoid accidental paid events during development.

**Synthetic events:** Apify can add `apify-actor-start` automatically, which can charge even for otherwise empty runs. If you require strictly zero total event charges for blocked or empty runs, review and disable synthetic start pricing, accepting the startup-compute tradeoff. Do not promise zero customer charges without checking this.

**Illustration only, not measured unit economics:**
- Completed report event revenue: $0.25
- Creator's share at 80%: $0.20
- Assumed cloud run cost: $0.01
- Approximate remainder: $0.19 (before taxes, discounts, refunds, support, or any other costs)

Apify's PPE documentation states a payout of 80% of paid revenue minus platform usage costs. Free-plan user runs are excluded from monetized creator revenue. Recheck the official documentation and your account's billing data before using these numbers commercially.

**Payouts from Albania:** Account-specific verification remains required. Review Apify Console's payouts/KYC, payment method availability, tax documents and minimum payout terms. Do not assume an Albanian bank account is accepted until the actual payout setup confirms it.

Official reference: https://docs.apify.com/actors/monetize/pay-per-event
