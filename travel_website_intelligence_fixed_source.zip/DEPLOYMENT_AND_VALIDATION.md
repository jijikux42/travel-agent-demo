# Deployment and validation — owner action required

## What this package is

A revised copy of the actual user-supplied `source-code.zip`, not an unrelated template. The existing Apify Actor has **not** been modified. The existing 0.2 / last successful 0.2.2 build remains in place.

Modified files: `my_actor/main.py`, `my_actor/extractors.py`, `.actor/dataset_schema.json`, `README.md`. Tests and documentation were added. Other original files were preserved.

## Safest way to deploy

1. In Apify Console open **Travel Website Intelligence → Source**.
2. Preserve the current working source/build. Use Apify's **create new source version** function (a new version, e.g. 0.3) before changing code, where available.
3. Upload this ZIP as source using the supported upload/import control, **or** update the four modified files in the new version individually. Do not paste the ZIP's raw bytes into the code editor.
4. Build the new version and inspect the build log. Do not publish or change monetization.
5. Run the authorized demo with `{ "url": "https://jijikux42.github.io/travel-agent-demo/", "maxPages": 1 }`.
6. Confirm 3 distinct tours, 3 corresponding prices, 3 linked durations, and 3 booking/demo links whose path includes `/travel-agent-demo/index.html` and query contains the matching `booking=` token.
7. Confirm `REPORT`, `RESULTS.json` and `RESULTS.csv` are present and show the correct source URLs.
8. Run an additional small regression against an accessible allowed product site if desired, and ensure book catalogue item links are not treated as booking links.
9. Only after successful cloud tests, consider Store listing, pay-per-event setup, payments and public release with explicit approval.

## Why the bug occurred

The original `_normalize(url)` called `url.rstrip('/')`, turning `https://jijikux42.github.io/travel-agent-demo/` into `https://jijikux42.github.io/travel-agent-demo`. Relative `index.html?booking=...` links then resolved to `https://jijikux42.github.io/index.html?...`, outside the project directory. The fix preserves the slash, uses the page's actual final URL and retains the link's query.

## Remaining limitations

- Only **offline tests and a fully mocked HTTP Actor run** were completed in this package; a live Apify run still needs to be executed from the new source version.
- The current runner is an HTTP scraper. Some sites (including trips4fun.al as previously observed) return HTTP 406. This package does not bypass blocking.
- Overlap between pages cannot establish one canonical "original" price source. Reports honestly identify the *first observed page* and all observed pages.
- Real-world tourism websites have varied HTML; the test fixture is not proof of broad extraction accuracy.
- Web crawling and commercial safety checks may require more work for arbitrary user inputs (private-network SSRF filtering, domain-specific robots behavior, unexpected redirects and pricing-spend limits).
- Apify cloud billing, publishing, event naming and KYC/payouts are not configured.
