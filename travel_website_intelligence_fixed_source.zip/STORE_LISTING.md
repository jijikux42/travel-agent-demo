# Proposed Apify Store listing (draft, not published)

**Title:** Travel Website Intelligence — Tours, Prices & Booking Links

**Short description:** Analyze up to 10 public travel-business pages. Extract tour offers, advertised prices, durations, booking links and contacts into structured JSON/CSV with observed source URLs.

**Who it helps:** Independent tour operators, travel agencies, market researchers and consultants reviewing accessible public tourism websites.

**Key benefits**
- One URL in, structured findings out
- Prices paired with identifiable tour or service names
- Public booking-link and duration discovery
- CSV/JSON exports plus a compact website diagnostics report
- Transparent source references and skipped-page warnings

**Typical workflow**
1. Enter the travel website URL.
2. Set pages to examine (up to 10).
3. Run the Actor on a site you have permission to automate.
4. Download the dataset and report; validate important prices at their source URLs.

**Keywords:** travel website scraper, tour operator data, tour prices, booking link extractor, hotel website analysis, tourism market research, competitive analysis, tour duration, Apify Actor, business intelligence

**Accuracy disclaimer:** Rule-based extraction; not a booking engine, reservation checker or live-availability service. JavaScript-only content and restricted sites may not be supported. A source URL identifies observation, not independent validation.

**Pricing recommendation (not configured):** Evaluate a single custom `completed-report` pay-per-event charge, initially $0.25 per validated completed report, subject to cost tests, current commission, and Apify settings. No chargeable report event for empty or blocked runs. Synthetic start events may still charge unless explicitly disabled.

**Required before publication:** Corrected new Apify build, successful real cloud demo run, output check, pricing and event setup, sample run, payout verification, compliance review, and owner approval.
